package control;

import Window.win;

public class Main {
	public static void main(String[] args) {
		win thiswin = new win("Inventory Manager");
		thiswin.run();
	}

}
