Assignment 5

Ryan Rutherford

Collaborated with: Julian Brunealt

We went ahead and changed the UI to use the MDI format rather than what we were using previously, so we overhauled the code a bit.